import { userModel } from "../models/userModel.js";

async function hashPassword(password) {
  const data = new TextEncoder().encode(password);
  const hash = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, "0")).join("");
}

function getToken(req) {
  const cookie = req.headers.get("cookie");

  if (!cookie) {
    return null;
  }

  const match = cookie.match(/session=([^;]+)/);

  if (match) {
    return match [1];
  }

  return null;
}

export const authController = {

  register: async (req) => {
    const form     = await req.formData();
    const username = form.get("username");
    const email    = form.get("email");
    const password = form.get("password");
    const confirm  = form.get("confirm_password");

    switch(true) {
      case !username:
        return new Response("Please enter a username", { status: 400 });
      case !email:
        return new Response("Please enter an email", { status: 400 });
      case !password:
        return new Response("Please enter a password", { status: 400 });
      case password !== confirm:
        return new Response("Passwords do not match", { status: 400 });
      case !!userModel.findByEmail(email):
        return new Response("Email is already registered!", { status: 400 });
    }

    const hashed = await hashPassword(password);
    userModel.create(username, email, hashed);

    return new Response(null, { status: 302, headers: { "location": "/login" } });
  },

  login: async (req) => {
    console.log("login hit");
    const form     = await req.formData();
    const email    = form.get("email");
    const password = form.get("password");
    const user = userModel.findByEmail(email);
    const hashed = await hashPassword(password);

    switch (true) {
      case !user || hashed !== user.password:
        return new Response("Wrong email or Password", { status: 401 });
    }

    const token = crypto.randomUUID();
    userModel.createSession(token, user.id);

    return new Response("ok", { status: 200, headers: { "set-cookie": `session=${token}; HttpOnly; Path=/` }
    });
  },

  logout: (req) => {
    const token = getToken(req);
    
    if (token) userModel.deleteSession(token);
    return new Response(null, { status: 302, headers: { "location": "/login", "set-cookie": "session=; HttpOnly; Path=/; Max-Age=0" }
    });
  },

  getUser: (req) => {
    const token = getToken(req);
    console.log("token from cookie:", token);
    
    if (!token) 
      return null;
    return userModel.findBySession(token);
  }

};