import { bookingModel } from "../models/bookingModel.js";
import { authController } from "./authController.js";

export const bookingController = {

  book: (req) => {
    const user = authController.getUser(req);

    if (!user) {
      return new Response("Not logged in", { status: 401 });
    }

    const eventId = new URL(req.url).searchParams.get("event_id");
    const booked  = bookingModel.create(user.id, eventId);

    if (!booked) {
      return new Response("Event already booked", { status: 400 });
    }

    return new Response("Booked", { status: 200 });
  },

  getMyBookings: (req) => {
    const user = authController.getUser(req);

    if (!user) {
      return new Response("You are not logged in", { status: 401 });
    }

   const bookings = bookingModel.getByUser(user.id);

    return new Response(JSON.stringify(bookings), {
      headers: { "content-type": "application/json" }
    });
  },

  cancel: (req) => {
    const user = authController.getUser(req);

    if (!user) {
      return new Response("You are not logged in", { status: 401 });
    }

    const eventId = new URL(req.url).searchParams.get("event_id");
    bookingModel.remove(user.id, eventId);

    return new Response(null, { status: 302, headers: { "location": "/dashboard" } });
  }

};