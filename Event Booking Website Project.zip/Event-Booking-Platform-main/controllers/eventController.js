import { eventModel } from "../models/eventModel.js";
import { authController } from "./authController.js";

export const eventController = {

    getAll: () => {
        const events = eventModel.getAll();

        return new Response(JSON.stringify(events), { headers: { "content-type": "application/json" }
    });
    },

    create: async (req) => {
        const user = authController.getUser(req);
        const body = await req.json();

        switch (true) {
            case !user || user.role !=="admin":
                return new Response("Not allowed", { status: 403 });
            case !body.title || !body.date || !body.location:
                return new Response("Please fill all fields", { status: 400 });
        }

        const description = body.description;
        eventModel.create(body.title, body.date, body.location, description);

        return new Response("Event added", { status: 201 });
    },

    remove: (req) => {
        const user = authController.getUser(req);

        if (!user || user.role !== "admin") {
            return new Response("Not Allowed", { status: 403 });
        }

        const id = new URL(req.url).searchParams.get("id");
        eventModel.remove(id);

        return new Response("Event deleted", { status: 200 });
    }

};