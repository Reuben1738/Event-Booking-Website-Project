const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css":  "text/css; charset=utf-8",
  ".js":   "application/javascript; charset=utf-8",
  ".svg":  "image/svg+xml",
  ".png":  "image/png",
  ".jpg":  "image/jpeg",
};

export async function serveFile(filePath) {
  const ext = filePath.slice(filePath.lastIndexOf("."));
  
  let contentType = mimeTypes[ext];

  if (!contentType) {
    contentType = "text/plain";
  }

  try {
    let file;

    const isImage = [".jpg", ".jpeg", ".png"].includes(ext);

    if (isImage) {
      file = await Deno.readFile(filePath);
    } else {
      file = await Deno.readTextFile(filePath);
    }

    return new Response(file, { headers: { "content-type": contentType } });
  } catch (err) {
    console.error(`Could not serve ${filePath} - ${err.message}`);
    return new Response("file not found", { status: 404 });
  }
}