import db from "./db.js";

export const bookingModel = {

  create: (userId, eventId) => {
    const already = db.prepare("SELECT * FROM bookings WHERE user_id = ? AND event_id = ?").get(userId, eventId);
    
    if (already) {
      return false;
    }

    db.prepare("INSERT INTO bookings (user_id, event_id) VALUES (?, ?)").run(userId, eventId);
    
    return true;
  },

  getByUser: (userId) => {
    return db.prepare(`
      SELECT events.* FROM events
      JOIN bookings ON bookings.event_id = events.id
      WHERE bookings.user_id = ?
    `).all(userId);
  },

  remove: (userId, eventId) => {
    db.prepare("DELETE FROM bookings WHERE user_id = ? AND event_id = ?").run(userId, eventId);
  }

};