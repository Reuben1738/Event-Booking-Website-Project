import { Database } from "sqlite";

const db = new Database("events.db");

db.exec(`CREATE TABLE IF NOT EXISTS events (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  title       TEXT NOT NULL,
  date        TEXT NOT NULL,
  location    TEXT NOT NULL,
  description TEXT
)`);

db.exec(`CREATE TABLE IF NOT EXISTS users (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT,
  email    TEXT,
  password TEXT,
  role     TEXT DEFAULT 'user'
)`);

db.exec(`CREATE TABLE IF NOT EXISTS sessions (
  token   TEXT,
  user_id INTEGER
)`);

db.exec(`CREATE TABLE IF NOT EXISTS bookings (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id  INTEGER,
  event_id INTEGER
)`);

const empty = db.prepare("SELECT COUNT(*) as count FROM events").get().count === 0;
if (empty) {
  db.exec(`INSERT INTO events (title, date, location, description) VALUES
    ('Metallica',              '2026-09-05', 'London',     'Metallica concert in London.'),
    ('Elton John - Rocketman', '2026-08-10', 'Manchester', 'Elton John concert in Manchester.'),
    ('Linkin Park',            '2026-07-15', 'Birmingham', 'Linkin Park concert in Birmingham.'),
    ('Rolling Loud',           '2026-12-28', 'London',     'Rolling Loud in O2 Arena.'),
    ('Kendrick/Drake',         '2026-11-15', 'Coventry',   'Kendrick and Drake show in Coventry.')
  `);
}

const adminExists = db.prepare("SELECT * FROM users WHERE role = 'admin'").get();
if (!adminExists) {
  db.prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)").run(
    "admin",
    "admin@planevent.com",
    "240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9",
    "admin"
  );
}

export default db;