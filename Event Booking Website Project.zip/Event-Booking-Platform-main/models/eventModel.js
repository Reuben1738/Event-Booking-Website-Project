import db from "./db.js";

export const eventModel = {

  getAll: () => {
    return db.prepare("SELECT * FROM events").all();
  },

  create: (title, date, location, description) => {
    db.prepare("INSERT INTO events (title, date, location, description) VALUES (?, ?, ?, ?)").run(title, date, location, description);
  },

  remove: (id) => {
    db.prepare("DELETE FROM events WHERE id = ?").run(id);
  }

};