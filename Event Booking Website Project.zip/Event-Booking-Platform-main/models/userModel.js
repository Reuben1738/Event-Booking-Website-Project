import db from "./db.js";

export const userModel = {

  create: (username, email, password) => {
    db.prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)").run(username, email, password);
  },

  findByEmail: (email) => {
    return db.prepare("SELECT * FROM users WHERE email = ?").get(email);
  },

  createSession: (token, userId) => {
    db.prepare("INSERT INTO sessions (token, user_id) VALUES (?, ?)").run(token, userId);
  },

  findBySession: (token) => {
    return db.prepare(`
      SELECT users.* FROM users
      JOIN sessions ON sessions.user_id = users.id
      WHERE sessions.token = ?
    `).get(token);
  },

  deleteSession: (token) => {
    db.prepare("DELETE FROM sessions WHERE token = ?").run(token);
  }

};