import { serveFile } from "./controllers/staticController.js";
import { eventController } from "./controllers/eventController.js";
import { authController } from "./controllers/authController.js";
import { bookingController } from "./controllers/bookingController.js";

const pages = {
  "/":                "./views/planevent.html",
  "/home":            "./views/Home.html",
  "/about":           "./views/about.html",
  "/forgot-password": "./views/forgot-password.html",
  "/browse-events":   "./views/browse-event.html",
};

export async function routeRequest(req) {
  const path   = new URL(req.url).pathname;
  const method = req.method;
  console.log(method, path);

  if (pages[path]) return serveFile(pages[path]);

  if (method === "GET"  && path === "/login")  
    return serveFile("./views/login.html");
  
  if (method === "GET"  && path === "/signup") 
    return serveFile("./views/signup.html");

  if (method === "GET" && path === "/add-event") {
    const user = authController.getUser(req);
    
    if (!user) 
      return new Response(null, { status: 302, headers: { "location": "/login" } });
    
    if (user.role !== "admin") 
      return new Response("Not allowed", { status: 403 });
    
    return serveFile("./views/add-event.html");
  }

  if (path === "/dashboard") {
    const user = authController.getUser(req);
    
    if (!user) 
      return new Response(null, { status: 302, headers: { "location": "/login" } });
    
    return serveFile("./views/dashboard.html");
  }

  if (method === "GET" && path === "/me") {
    const user = authController.getUser(req);
    
    if (!user) 
      return new Response("Not logged in", { status: 401 });
    
    return new Response(JSON.stringify({
    id:       user.id,
    username: user.username,
    email:    user.email,
    role:     user.role 
  }), {
    headers: { "content-type": "application/json" }
  });
}

  if (method === "POST" && path === "/register")      return authController.register(req);
  if (method === "POST" && path === "/login")         return authController.login(req);
  if (method === "GET"  && path === "/logout")        return authController.logout(req);

  if (method === "GET" && path === "/book")           return bookingController.book(req);
  if (method === "GET" && path === "/my-bookings")    return bookingController.getMyBookings(req);
  if (method === "GET" && path === "/cancel-booking") return bookingController.cancel(req);

  if (method === "GET" && path === "/get-events")      return eventController.getAll();
  if (method === "POST" && path === "/add-event")      return eventController.create(req);
  if (method === "DELETE" && path === "/delete-event") return eventController.remove(req);

  if (path.startsWith("/public/")) 
    
    return serveFile(`.${path}`);

  return new Response("Page not found", { status: 404 });
}