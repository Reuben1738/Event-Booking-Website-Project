import { routeRequest } from "./router.js";

Deno.serve({ port: 8000 } , (req) => routeRequest(req));

console.log("Server is running");